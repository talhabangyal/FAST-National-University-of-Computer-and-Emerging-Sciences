:


from typing import List, Tuple
import heapq
from collections import deque

class SearchAlgorithm:
    
    @staticmethod
    def get_neighbors(x: int, y: int, grid: List[List[str]]) -> List[Tuple[int, int]]:
       

    @staticmethod
    def get_start_target(grid: List[List[str]]) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        
        return start, target
    
        
    # Implement Uniform search
    
    @staticmethod
    def ucs(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]]]:
       

    # Implement Depth First Search
 
    @staticmethod
    def dfs(grid: List[List[str]]) -> Tuple[int, List[List[str]]]:
       
            
    
    # Implement Breadth First Search
    @staticmethod
    def bfs(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]]]:
       

        
    # Implement Best First Search
    @staticmethod
    def best_first_search(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]]]:
        

    
    # Implement A* Search
    @staticmethod
    def a_star_search(grid: List[List[str]]) -> Tuple[int, List[List[str]]]:
       

    
   
if __name__ == "__main__":

    example  = [
    ['0', '0', '0', '0'],
    ['0', '-1', '-1', 't'],
    ['s', '0', '-1', '0'],
    ['0', '0', '0', '-1']
]

    found, final_state = SearchAlgorithm.best_first_search(example)
    ## Show output in GUI form (as a matrix). You can use Matplotlib or Seaborn for visualization of Grid. 

# In[ ]:




